-- جدول الجلسات الجديد (يستبدل $_SESSION في PHP)
create table if not exists quiz_sessions (
  id uuid primary key default gen_random_uuid(),
  question_ids int[] not null,
  answers jsonb not null default '{}',
  created_at timestamptz not null default now()
);
-- فعّل RLS بدون سياسات: لا يصل للجداول إلا مفتاح service_role من الخادم
alter table quiz_sessions enable row level security;
alter table questions     enable row level security;
alter table quiz_results  enable row level security;
-- اختياري: حذف الجلسات القديمة
-- delete from quiz_sessions where created_at < now() - interval '1 day';
